# Facial Expression Recognition > 2024-08-17 1:03pm
https://universe.roboflow.com/yolov8-g7lrh/facial-expression-recognition-jw8ie

Provided by a Roboflow user
License: CC BY 4.0

